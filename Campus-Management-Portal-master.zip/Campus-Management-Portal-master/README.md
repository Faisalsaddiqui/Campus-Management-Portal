# Campus Management System Laravel

  

## **\*** WORK IN PROGRESS **\***

# Installation instructions  

    npm install
    
    composer install 

    npm run dev
    
    php artisan migrate
    
    php artisan db:seed

This will generate a User model with admin and super admin roles.

**Super Admin account Credentials:**

  

- Email: admin@mail.com

- Password: password

# Conventions
Every directory for Pages/Controller/Components correspond with a role.
***example:*** Pages/Student contains all pages associated with students. 

Any shared components will be in shared directory
