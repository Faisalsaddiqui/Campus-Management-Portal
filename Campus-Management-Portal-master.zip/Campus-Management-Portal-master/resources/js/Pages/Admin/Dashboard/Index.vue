<script setup>
import { Head } from "@inertiajs/vue3";

</script>
<template>
    <div>
        <Head title="Dashboard - Admin" />
        <p>
            This is dashboard admin!
        </p>
    </div>
</template>


