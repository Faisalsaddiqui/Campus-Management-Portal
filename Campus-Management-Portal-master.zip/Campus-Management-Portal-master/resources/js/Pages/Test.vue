<template>
	<div>
		{{ body }}
	</div>
</template>

<script>
export default {
	props: {
		body: {
			required: true
		}
	}
};
</script>

<style>
</style>