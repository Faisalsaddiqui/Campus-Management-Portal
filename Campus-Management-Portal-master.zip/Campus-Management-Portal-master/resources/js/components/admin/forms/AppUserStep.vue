<template> </template>

<script>
export default {
	props: {
		form: {
			type: Object,
			required: true
		}
	}
};
</script>