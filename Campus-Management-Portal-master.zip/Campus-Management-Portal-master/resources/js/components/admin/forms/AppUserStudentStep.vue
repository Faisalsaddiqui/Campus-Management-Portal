<template>
	<div>
		<div class="form-row">
			<div>
				<label class="block">Student Name: </label>
				<input type="text" class="form-input" />
				<div class="text-red-600"></div>
			</div>
			<div>
				<label class="block">Email: </label>
				<input type="text" class="form-input" />
			</div>
		</div>
	</div>
</template>

<script>
export default {};
</script>
