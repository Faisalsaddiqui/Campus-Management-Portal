<template>
	<div>Couldnt load the component. Check your internet</div>
</template>

<script>
export default {};
</script>
