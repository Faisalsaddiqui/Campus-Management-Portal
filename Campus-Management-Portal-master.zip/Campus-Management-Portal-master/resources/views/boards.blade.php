<section class="col col-4 col-md-4">
  <label class="label">Board/University</label>
  <label class="input">
  <div class="select2-container form-control" id="s2id_autogen122" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-123">Select</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen123" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-123" id="s2id_autogen123"></div><select class="form-control select2-offscreen" name="UNI_BOARD_CODE" required="" title="" tabindex="-1">
  <option value="">Select</option>
  <option value="135">
  Abasyn University, Peshawar&nbsp;</option>
  <option value="90">
  Aga Khan University, Karachi</option>
  <option value="21">
  Air University, Islamabad</option>
  <option value="121">
  Al-Hamd Islamic University, Quetta</option>
  <option value="146">
  Al-Khair University, AJK</option>
  <option value="22">
  Allama Iqbal Open University, Islamabad</option>
  <option value="166">
  BISE Abbottabad</option>
  <option value="165">
  BISE BANNU</option>
  <option value="6">
  BISE Bahawalpur</option>
  <option value="7">
  BISE D.G. Khan</option>
  <option value="1">
  BISE Faisalabad</option>
  <option value="3">
  BISE Gujranwala</option>
  <option value="158">
  BISE Hyderabad</option>
  <option value="161">
  BISE Karachi</option>
  <option value="157">
  BISE Karachi</option>
  <option value="2">
  BISE Lahore</option>
  <option value="159">
  BISE Larkana</option>
  <option value="163">
  BISE MIRPURKHAS</option>
  <option value="4">
  BISE Multan</option>
  <option value="160">
  BISE PESHAWAR</option>
  <option value="152">
  BISE Quetta</option>
  <option value="5">
  BISE Rawalpindi</option>
  <option value="154">
  BISE Sahiwal</option>
  <option value="8">
  BISE Sargodha</option>
  <option value="162">
  BISE Sawat</option>
  <option value="38">
  Bahauddin Zakariya University, Multan</option>
  <option value="23">
  Bahria University, Islamabad</option>
  <option value="115">
  Balochistan University of Engineering and Technology, Khuzdar</option>
  <option value="116">
  Balochistan University of Information Technology and Management Sciences, Quetta</option>
  <option value="91">
  Baqai Medical University, Karachi</option>
  <option value="59">
  Beaconhouse National University, Lahore</option>
  <option value="184">
  Board of Islamic Education</option>
  <option value="117">
  Bolan University of Medical  Sciences, Quetta, Quetta</option>
  <option value="136">
  CECOS University of Information Technology and Emerging Sciences, Peshawar</option>
  <option value="24">
  COMSATS Institute of Information Technology, Islamabad &nbsp;</option>
  <option value="137">
  City University of Science  Technology, Peshawar</option>
  <option value="76">
  Commecs Institute of Business  Sciences, Karachi</option>
  <option value="93">
  DHA Suffa University, Karachi</option>
  <option value="92">
  Dadabhoy Institute of Higher Education, Karachi</option>
  <option value="77">
  Dawood College of Engineering , Karachi</option>
  <option value="78">
  Dow University of Health Sciences, Karachi</option>
  <option value="39">
  Fatima Jinnah Women University, Rawalpindi</option>
  <option value="9">
  Federal Board</option>
  <option value="25">
  Federal Urdu University of Arts, Sciences and Technology, Islamabad</option>
  <option value="60">
  Forman Christian College, Lahore</option>
  <option value="36">
  Foundation University, Islamabad</option>
  <option value="123">
  Frontier Women University, Peshawar</option>
  <option value="61">
  GIFT University, Gujranwala</option>
  <option value="138">
  Gandhara University, Peshawar</option>
  <option value="164">
  Ghazi University Dera Ghazi Khan,Pakistan</option>
  <option value="139">
  Ghulam Ishaq Khan Institute of Engineering Sciences , Topi</option>
  <option value="124">
  Gomal University, D.I.Khan</option>
  <option value="40">
  Government College University, Faisalabad</option>
  <option value="41">
  Government College University, Lahore</option>
  <option value="155">
  Government College Women University Faisalabad</option>
  <option value="156">
  Government college women university sialkot</option>
  <option value="94">
  Greenwich University, Karachi</option>
  <option value="62">
  Hajvery University, Lahore</option>
  <option value="95">
  Hamdard University, Karachi</option>
  <option value="125">
  Hazara University, Dodhial, Mansahra</option>
  <option value="63">
  Imperial College of Business Studies, Lahore</option>
  <option value="96">
  Indus Institute of Higher Education, Karachi</option>
  <option value="97">
  Indus Valley School of Art and Architecture, Karachi</option>
  <option value="98">
  Institute of Business  BIZTEK, Karachi</option>
  <option value="79">
  Institute of Business Administration, Karachi</option>
  <option value="99">
  Institute of Business Management, Karachi</option>
  <option value="126">
  Institute of Management Sciences (IMSciences), Peshawar</option>
  <option value="64">
  Institute of Management Sciences, Lahore</option>
  <option value="26">
  Institute of Space Technology (IST), Islamabad</option>
  <option value="27">
  International Islamic University, Islamabad</option>
  <option value="100">
  Iqra University, Karachi</option>
  <option value="122">
  Iqra University, Quetta</option>
  <option value="127">
  Islamia College University, Peshawar, Peshawar</option>
  <option value="42">
  Islamia University, Bahawalpur</option>
  <option value="101">
  Isra University, Hyderabad</option>
  <option value="175">
  Ittehad-ul-Madaris Al-Arabia Pakistan, Mardan</option>
  <option value="176">
  Ittehad-ul-Madaris Al-Islamia Pakistan, Lahore</option>
  <option value="102">
  Jinnah University for Women, Karachi</option>
  <option value="104">
  KASB (Khadim Ali Shah Bukhari) Institute of Technology, Karachi</option>
  <option value="185">
  Kanz-ul-Madaris</option>
  <option value="103">
  Karachi Institute of Economics , Karachi</option>
  <option value="147">
  Karakurum International University, Gilgit</option>
  <option value="128">
  Khyber Medical University, Peshawar</option>
  <option value="43">
  King Edward Medical University, Lahore</option>
  <option value="44">
  Kinnaird College for Women, Lahore</option>
  <option value="129">
  Kohat University of Science , Kohat</option>
  <option value="45">
  Lahore College for Women University, Lahore</option>
  <option value="167">
  Lahore Garrison University</option>
  <option value="153">
  Lahore LEADS University</option>
  <option value="65">
  Lahore School of Economics, Lahore</option>
  <option value="66">
  Lahore University of Management Sciences, Lahore</option>
  <option value="118">
  Lasbela University of Agriculture, Water  Science, Lasbela</option>
  <option value="80">
  Liaquat University of Medical and Health Sciences, Jamshoro</option>
  <option value="178">
  Majma-ul-Madaris Taleem ul Kitab wal Hikmat, Lahore</option>
  <option value="182">
  Majma-ul-Uloom Al-Islamia</option>
  <option value="81">
  Mehran University of Eng. , Jamshoro</option>
  <option value="151">
  Minhaj University Lahore</option>
  <option value="67">
  Minhaj University, Lahore</option>
  <option value="144">
  Mirpur University of Science and Technology (MUST), AJ, AJK</option>
  <option value="105">
  Mohammad Ali Jinnah University, Karachi</option>
  <option value="145">
  Mohi-ud-Din Islamic University, AJK</option>
  <option value="82">
  NED University of Engineering , Karachi</option>
  <option value="130">
  NWFP Agriculture University, Peshawar</option>
  <option value="131">
  NWFP University of Engineering , Peshawar</option>
  <option value="46">
  National College of Arts, Lahore</option>
  <option value="68">
  National College of Buisness Administration (NCBA), Lahore</option>
  <option value="34">
  National Defence University, Islamabad</option>
  <option value="47">
  National School of Public Policy, Lahore</option>
  <option value="48">
  National Textile University, Faisalabad (Federal Chartered), Faisalabad</option>
  <option value="37">
  National University of Computer and Emerging Sciences, Islamabad</option>
  <option value="28">
  National University of Modern Languages, Islamabad&nbsp;</option>
  <option value="32">
  National University of Science and Technology, Rawalpindi</option>
  <option value="106">
  Nazeer Hussain University&nbsp;</option>
  <option value="107">
  Newports Institute of Communications and Economics, Karachi</option>
  <option value="177">
  Nizam-ul-Madaris Pakistan, Lahore</option>
  <option value="140">
  Northern University, Nowshera</option>
  <option value="10">
  Other Board</option>
  <option value="150">
  Other University</option>
  <option value="30">
  Pakistan Institute of Development Economics</option>
  <option value="29">
  Pakistan Institute of Engineering Applied Sciences, Islamabad</option>
  <option value="132">
  Pakistan Military Academy, Malakand</option>
  <option value="83">
  Pakistan Naval Academy, Karachi</option>
  <option value="108">
  Preston Institute of Management Sciences and Technology, Karachi</option>
  <option value="109">
  Preston University, Karachi</option>
  <option value="141">
  Preston University, Kohat</option>
  <option value="11">
  Punjab Borad of Technical Education, Lahore</option>
  <option value="84">
  Quaid-e-Awam University of Engineering, Science , Nawabshah</option>
  <option value="31">
  Quaid-i-Azam University, Islamabad</option>
  <option value="142">
  Qurtaba University of Science  Technology, D.I.Khan</option>
  <option value="174">
  Rabita-ul-Madaris Al-Islamia, Lahore</option>
  <option value="35">
  Riphah International University, Islamabad</option>
  <option value="119">
  Sardar Bahadur Khan Women University, Quetta</option>
  <option value="143">
  Sarhad University of Science  Technology, Peshawar</option>
  <option value="85">
  Shah Abdul Latif University, Khairpur</option>
  <option value="110">
  Shaheed Zulfikar Ali Bhutto Institute of Science  (SZABIST), Karachi</option>
  <option value="86">
  Sindh Agriculture University, Tandojam</option>
  <option value="111">
  Sir Syed University of Engg. , Karachi</option>
  <option value="87">
  Sukkur Institute of Business Administration, Sukkur</option>
  <option value="171">
  Tanzeem-ul-Madaris Ahle Sunnat, Lahore</option>
  <option value="112">
  Textile Institute of Pakistan, Karachi</option>
  <option value="69">
  The Superior College, Lahore</option>
  <option value="169">
  The University of Azad Jammu and Kashmir Muzaffarabad</option>
  <option value="53">
  University Of Engineering , Taxila, Rawalpindi</option>
  <option value="49">
  University of Agriculture, Faisalabad</option>
  <option value="50">
  University of Arid Agriculture, Murree Road, Rawalpindi</option>
  <option value="120">
  University of Balochistan, Quetta</option>
  <option value="70">
  University of Central Punjab, Lahore</option>
  <option value="113">
  University of East, Hyderabad</option>
  <option value="51">
  University of Education, Lahore</option>
  <option value="52">
  University of Engineering , Lahore</option>
  <option value="71">
  University of Faisalabad, Faisalabad</option>
  <option value="54">
  University of Gujrat, Gujrat</option>
  <option value="55">
  University of Health Sciences, Lahore</option>
  <option value="88">
  University of Karachi, Karachi</option>
  <option value="72">
  University of Lahore, Lahore</option>
  <option value="73">
  University of Management and Technology, Lahore</option>
  <option value="168">
  University of Narowal</option>
  <option value="133">
  University of Peshawar, Peshawar</option>
  <option value="56">
  University of Sargodha, Sargodha</option>
  <option value="134">
  University of Science  Bannu, Bannu</option>
  <option value="89">
  University of Sindh, Jamshoro</option>
  <option value="74">
  University of South Asia, Lahore</option>
  <option value="58">
  University of Veterinary and Animal Sciences, Lahore</option>
  <option value="75">
  University of Wah, Wah</option>
  <option value="57">
  University of the Punjab, Lahore</option>
  <option value="33">
  Virtual university of Pakistan, Lahore</option>
  <option value="170">
  Wafaq-ul-Madaris Al-Arabia, Multan</option>
  <option value="181">
  Wafaq-ul-Madaris Al-Arabia, Multan</option>
  <option value="179">
  Wafaq-ul-Madaris Al-Islamia Al Rizvia Pakistan</option>
  <option value="172">
  Wafaq-ul-Madaris Al-Salfia, Faisalbad</option>
  <option value="173">
  Wafaq-ul-Madaris Shia, Lahore</option>
  <option value="180">
  Wafaq-ul-Madaris Wal Jamiaat Al-Deeniya Al-Bakistania</option>
  <option value="183">
  Wahdat-ul-Madaris Al-Islamia, Pakistan</option>
  <option value="114">
  Ziauddin Medical University, Karachi</option>
  </select>

  </label>
</section>