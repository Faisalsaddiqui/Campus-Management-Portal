<form class="smart-form" id="fname" method="post" action="">
  <fieldset>




    <div class="row">
      <section class="col col-4">
          <label class="label">Degree Type</label>
          <label class="input">
              <div class="select2-container form-control" id="s2id_DEG_ID" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-119">
                      Secondary School Certificate / Matriculation / O - level</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen119" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-119" id="s2id_autogen119"></div><select class="form-control select2-offscreen" name="DEG_ID" id="DEG_ID" required="" title="" tabindex="-1">
                <option value="">Select</option>
                                                                        <option value="1">
                      Secondary School Certificate / Matriculation / O - level</option>
                                                                      </select>
          </label>
      </section>
      <section class="col col-4">

          <label class="label">Degree title</label>
          <label class="input">
            <div class="control-group" id="DEG_TITLEE" style="">
  <div class="col-sm-12 controls">
  <div class="select2-container form-control" id="s2id_DEG_TITLE"><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-120">Matriculation(Science)</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen120" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-120" id="s2id_autogen120"></div><select name="DEG_TITLE" id="DEG_TITLE" class="form-control select2-offscreen" required="" tabindex="-1" title="">
  <option value="">Select Title</option>


  <option value="11">Matriculation(Arts)</option>
  <option value="10">Matriculation(Science)</option>
  <option value="12">O-Level</option>
  <option value="14">Other</option>
  <option value="13">Shahadatul Sanvia Aama</option>
  <!-- <option value="1">OTHER</option> -->

  </select> 
  </div>
  <div class="form_gap hidden-xs"></div>




  <script src="multiselect/select2.full.min.js"></script>
  <script type="text/javascript">
  $('select').select2({}).focus(function () { $(this).select2('focus'); });
  jQuery("#select-basic,#COST_TYPE").select2();
  jQuery('#select-search-hide').select2({
  minimumResultsForSearch: -1
  });  
  </script>
  </div>
      </label>


                    <!-- <div class="control-group" id="DEG_TITLEE">
  <select name="DEG_TITLE" id="DEG_TITLE"  class="form-control" required>
  <option value=""></option>
  </select>     
  </div> -->

  </section>
  <section class="col col-4">
  <label class="label">Exam Type</label>
  <label class="input">
  <div class="select2-container form-control" id="s2id_SEM_ANNUAL" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-121">Annual (1st)</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen121" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-121" id="s2id_autogen121"></div><select class="form-control select2-offscreen" name="SEM_ANNUAL" id="SEM_ANNUAL" required="" title="" tabindex="-1">
  <option value="">Select</option>
  <option value="A1">Annual (1st)</option>
  <option value="A2">Annual (2nd)/ Supplementary</option>
  <option value="S">Semester</option>
  </select>
  </label>
  </section>

  </div>

  <div class="row">
  <section class="col col-4 col-md-4">
    <label class="label">Board/University</label>
    <label class="input">
    <div class="select2-container form-control" id="s2id_autogen122" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-123">Select</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen123" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-123" id="s2id_autogen123"></div><select class="form-control select2-offscreen" name="UNI_BOARD_CODE" required="" title="" tabindex="-1">
    <option value="">Select</option>
    <option value="135">
    Abasyn University, Peshawar&nbsp;</option>
    <option value="90">
    Aga Khan University, Karachi</option>
    <option value="21">
    Air University, Islamabad</option>
    <option value="121">
    Al-Hamd Islamic University, Quetta</option>
    <option value="146">
    Al-Khair University, AJK</option>
    <option value="22">
    Allama Iqbal Open University, Islamabad</option>
    <option value="166">
    BISE Abbottabad</option>
    <option value="165">
    BISE BANNU</option>
    <option value="6">
    BISE Bahawalpur</option>
    <option value="7">
    BISE D.G. Khan</option>
    <option value="1">
    BISE Faisalabad</option>
    <option value="3">
    BISE Gujranwala</option>
    <option value="158">
    BISE Hyderabad</option>
    <option value="161">
    BISE Karachi</option>
    <option value="157">
    BISE Karachi</option>
    <option value="2">
    BISE Lahore</option>
    <option value="159">
    BISE Larkana</option>
    <option value="163">
    BISE MIRPURKHAS</option>
    <option value="4">
    BISE Multan</option>
    <option value="160">
    BISE PESHAWAR</option>
    <option value="152">
    BISE Quetta</option>
    <option value="5">
    BISE Rawalpindi</option>
    <option value="154">
    BISE Sahiwal</option>
    <option value="8">
    BISE Sargodha</option>
    <option value="162">
    BISE Sawat</option>
    <option value="38">
    Bahauddin Zakariya University, Multan</option>
    <option value="23">
    Bahria University, Islamabad</option>
    <option value="115">
    Balochistan University of Engineering and Technology, Khuzdar</option>
    <option value="116">
    Balochistan University of Information Technology and Management Sciences, Quetta</option>
    <option value="91">
    Baqai Medical University, Karachi</option>
    <option value="59">
    Beaconhouse National University, Lahore</option>
    <option value="184">
    Board of Islamic Education</option>
    <option value="117">
    Bolan University of Medical  Sciences, Quetta, Quetta</option>
    <option value="136">
    CECOS University of Information Technology and Emerging Sciences, Peshawar</option>
    <option value="24">
    COMSATS Institute of Information Technology, Islamabad &nbsp;</option>
    <option value="137">
    City University of Science  Technology, Peshawar</option>
    <option value="76">
    Commecs Institute of Business  Sciences, Karachi</option>
    <option value="93">
    DHA Suffa University, Karachi</option>
    <option value="92">
    Dadabhoy Institute of Higher Education, Karachi</option>
    <option value="77">
    Dawood College of Engineering , Karachi</option>
    <option value="78">
    Dow University of Health Sciences, Karachi</option>
    <option value="39">
    Fatima Jinnah Women University, Rawalpindi</option>
    <option value="9">
    Federal Board</option>
    <option value="25">
    Federal Urdu University of Arts, Sciences and Technology, Islamabad</option>
    <option value="60">
    Forman Christian College, Lahore</option>
    <option value="36">
    Foundation University, Islamabad</option>
    <option value="123">
    Frontier Women University, Peshawar</option>
    <option value="61">
    GIFT University, Gujranwala</option>
    <option value="138">
    Gandhara University, Peshawar</option>
    <option value="164">
    Ghazi University Dera Ghazi Khan,Pakistan</option>
    <option value="139">
    Ghulam Ishaq Khan Institute of Engineering Sciences , Topi</option>
    <option value="124">
    Gomal University, D.I.Khan</option>
    <option value="40">
    Government College University, Faisalabad</option>
    <option value="41">
    Government College University, Lahore</option>
    <option value="155">
    Government College Women University Faisalabad</option>
    <option value="156">
    Government college women university sialkot</option>
    <option value="94">
    Greenwich University, Karachi</option>
    <option value="62">
    Hajvery University, Lahore</option>
    <option value="95">
    Hamdard University, Karachi</option>
    <option value="125">
    Hazara University, Dodhial, Mansahra</option>
    <option value="63">
    Imperial College of Business Studies, Lahore</option>
    <option value="96">
    Indus Institute of Higher Education, Karachi</option>
    <option value="97">
    Indus Valley School of Art and Architecture, Karachi</option>
    <option value="98">
    Institute of Business  BIZTEK, Karachi</option>
    <option value="79">
    Institute of Business Administration, Karachi</option>
    <option value="99">
    Institute of Business Management, Karachi</option>
    <option value="126">
    Institute of Management Sciences (IMSciences), Peshawar</option>
    <option value="64">
    Institute of Management Sciences, Lahore</option>
    <option value="26">
    Institute of Space Technology (IST), Islamabad</option>
    <option value="27">
    International Islamic University, Islamabad</option>
    <option value="100">
    Iqra University, Karachi</option>
    <option value="122">
    Iqra University, Quetta</option>
    <option value="127">
    Islamia College University, Peshawar, Peshawar</option>
    <option value="42">
    Islamia University, Bahawalpur</option>
    <option value="101">
    Isra University, Hyderabad</option>
    <option value="175">
    Ittehad-ul-Madaris Al-Arabia Pakistan, Mardan</option>
    <option value="176">
    Ittehad-ul-Madaris Al-Islamia Pakistan, Lahore</option>
    <option value="102">
    Jinnah University for Women, Karachi</option>
    <option value="104">
    KASB (Khadim Ali Shah Bukhari) Institute of Technology, Karachi</option>
    <option value="185">
    Kanz-ul-Madaris</option>
    <option value="103">
    Karachi Institute of Economics , Karachi</option>
    <option value="147">
    Karakurum International University, Gilgit</option>
    <option value="128">
    Khyber Medical University, Peshawar</option>
    <option value="43">
    King Edward Medical University, Lahore</option>
    <option value="44">
    Kinnaird College for Women, Lahore</option>
    <option value="129">
    Kohat University of Science , Kohat</option>
    <option value="45">
    Lahore College for Women University, Lahore</option>
    <option value="167">
    Lahore Garrison University</option>
    <option value="153">
    Lahore LEADS University</option>
    <option value="65">
    Lahore School of Economics, Lahore</option>
    <option value="66">
    Lahore University of Management Sciences, Lahore</option>
    <option value="118">
    Lasbela University of Agriculture, Water  Science, Lasbela</option>
    <option value="80">
    Liaquat University of Medical and Health Sciences, Jamshoro</option>
    <option value="178">
    Majma-ul-Madaris Taleem ul Kitab wal Hikmat, Lahore</option>
    <option value="182">
    Majma-ul-Uloom Al-Islamia</option>
    <option value="81">
    Mehran University of Eng. , Jamshoro</option>
    <option value="151">
    Minhaj University Lahore</option>
    <option value="67">
    Minhaj University, Lahore</option>
    <option value="144">
    Mirpur University of Science and Technology (MUST), AJ, AJK</option>
    <option value="105">
    Mohammad Ali Jinnah University, Karachi</option>
    <option value="145">
    Mohi-ud-Din Islamic University, AJK</option>
    <option value="82">
    NED University of Engineering , Karachi</option>
    <option value="130">
    NWFP Agriculture University, Peshawar</option>
    <option value="131">
    NWFP University of Engineering , Peshawar</option>
    <option value="46">
    National College of Arts, Lahore</option>
    <option value="68">
    National College of Buisness Administration (NCBA), Lahore</option>
    <option value="34">
    National Defence University, Islamabad</option>
    <option value="47">
    National School of Public Policy, Lahore</option>
    <option value="48">
    National Textile University, Faisalabad (Federal Chartered), Faisalabad</option>
    <option value="37">
    National University of Computer and Emerging Sciences, Islamabad</option>
    <option value="28">
    National University of Modern Languages, Islamabad&nbsp;</option>
    <option value="32">
    National University of Science and Technology, Rawalpindi</option>
    <option value="106">
    Nazeer Hussain University&nbsp;</option>
    <option value="107">
    Newports Institute of Communications and Economics, Karachi</option>
    <option value="177">
    Nizam-ul-Madaris Pakistan, Lahore</option>
    <option value="140">
    Northern University, Nowshera</option>
    <option value="10">
    Other Board</option>
    <option value="150">
    Other University</option>
    <option value="30">
    Pakistan Institute of Development Economics</option>
    <option value="29">
    Pakistan Institute of Engineering Applied Sciences, Islamabad</option>
    <option value="132">
    Pakistan Military Academy, Malakand</option>
    <option value="83">
    Pakistan Naval Academy, Karachi</option>
    <option value="108">
    Preston Institute of Management Sciences and Technology, Karachi</option>
    <option value="109">
    Preston University, Karachi</option>
    <option value="141">
    Preston University, Kohat</option>
    <option value="11">
    Punjab Borad of Technical Education, Lahore</option>
    <option value="84">
    Quaid-e-Awam University of Engineering, Science , Nawabshah</option>
    <option value="31">
    Quaid-i-Azam University, Islamabad</option>
    <option value="142">
    Qurtaba University of Science  Technology, D.I.Khan</option>
    <option value="174">
    Rabita-ul-Madaris Al-Islamia, Lahore</option>
    <option value="35">
    Riphah International University, Islamabad</option>
    <option value="119">
    Sardar Bahadur Khan Women University, Quetta</option>
    <option value="143">
    Sarhad University of Science  Technology, Peshawar</option>
    <option value="85">
    Shah Abdul Latif University, Khairpur</option>
    <option value="110">
    Shaheed Zulfikar Ali Bhutto Institute of Science  (SZABIST), Karachi</option>
    <option value="86">
    Sindh Agriculture University, Tandojam</option>
    <option value="111">
    Sir Syed University of Engg. , Karachi</option>
    <option value="87">
    Sukkur Institute of Business Administration, Sukkur</option>
    <option value="171">
    Tanzeem-ul-Madaris Ahle Sunnat, Lahore</option>
    <option value="112">
    Textile Institute of Pakistan, Karachi</option>
    <option value="69">
    The Superior College, Lahore</option>
    <option value="169">
    The University of Azad Jammu and Kashmir Muzaffarabad</option>
    <option value="53">
    University Of Engineering , Taxila, Rawalpindi</option>
    <option value="49">
    University of Agriculture, Faisalabad</option>
    <option value="50">
    University of Arid Agriculture, Murree Road, Rawalpindi</option>
    <option value="120">
    University of Balochistan, Quetta</option>
    <option value="70">
    University of Central Punjab, Lahore</option>
    <option value="113">
    University of East, Hyderabad</option>
    <option value="51">
    University of Education, Lahore</option>
    <option value="52">
    University of Engineering , Lahore</option>
    <option value="71">
    University of Faisalabad, Faisalabad</option>
    <option value="54">
    University of Gujrat, Gujrat</option>
    <option value="55">
    University of Health Sciences, Lahore</option>
    <option value="88">
    University of Karachi, Karachi</option>
    <option value="72">
    University of Lahore, Lahore</option>
    <option value="73">
    University of Management and Technology, Lahore</option>
    <option value="168">
    University of Narowal</option>
    <option value="133">
    University of Peshawar, Peshawar</option>
    <option value="56">
    University of Sargodha, Sargodha</option>
    <option value="134">
    University of Science  Bannu, Bannu</option>
    <option value="89">
    University of Sindh, Jamshoro</option>
    <option value="74">
    University of South Asia, Lahore</option>
    <option value="58">
    University of Veterinary and Animal Sciences, Lahore</option>
    <option value="75">
    University of Wah, Wah</option>
    <option value="57">
    University of the Punjab, Lahore</option>
    <option value="33">
    Virtual university of Pakistan, Lahore</option>
    <option value="170">
    Wafaq-ul-Madaris Al-Arabia, Multan</option>
    <option value="181">
    Wafaq-ul-Madaris Al-Arabia, Multan</option>
    <option value="179">
    Wafaq-ul-Madaris Al-Islamia Al Rizvia Pakistan</option>
    <option value="172">
    Wafaq-ul-Madaris Al-Salfia, Faisalbad</option>
    <option value="173">
    Wafaq-ul-Madaris Shia, Lahore</option>
    <option value="180">
    Wafaq-ul-Madaris Wal Jamiaat Al-Deeniya Al-Bakistania</option>
    <option value="183">
    Wahdat-ul-Madaris Al-Islamia, Pakistan</option>
    <option value="114">
    Ziauddin Medical University, Karachi</option>
    </select>

    </label>
  </section>
  <section class="col col-2 col-md-2">
  <label class="label">Reg No./Roll No.</label>
  <label class="input">
  <input type="text" name="DEG_NO" id="DEG_NO" autocomplete="off" required="">
  </label>
  </section>
  <section class="col col-2">
  <label class="label">Passing Year</label>
  <label class="input">
  <div class="select2-container form-control" id="s2id_PASS_YEAR" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-124">Select Year</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen124" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-124" id="s2id_autogen124"><div class="select2-drop select2-display-none select2-with-searchbox">   <div class="select2-search">       <label for="s2id_autogen124_search" class="select2-offscreen"></label>       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input" role="combobox" aria-expanded="true" aria-autocomplete="list" aria-owns="select2-results-124" id="s2id_autogen124_search" placeholder="">   </div>   <ul class="select2-results" role="listbox" id="select2-results-124">   </ul></div></div><select class="form-control select2-offscreen" name="PASS_YEAR" id="PASS_YEAR" required="" title="" tabindex="-1">
  <option value="">Select Year</option>
  <option value="2022">
  2022</option>
  <option value="2021">
  2021</option>
  <option value="2020">
  2020</option>
  <option value="2019">
  2019</option>
  <option value="2018">
  2018</option>
  <option value="2017">
  2017</option>
  <option value="2016">
  2016</option>
  <option value="2015">
  2015</option>
  <option value="2014">
  2014</option>
  <option value="2013">
  2013</option>
  <option value="2012">
  2012</option>
  <option value="2011">
  2011</option>
  <option value="2010">
  2010</option>
  <option value="2009">
  2009</option>
  <option value="2008">
  2008</option>
  <option value="2007">
  2007</option>
  <option value="2006">
  2006</option>
  <option value="2005">
  2005</option>
  <option value="2004">
  2004</option>
  <option value="2003">
  2003</option>
  <option value="2002">
  2002</option>
  <option value="2001">
  2001</option>
  <option value="2000">
  2000</option>
  <option value="1999">
  1999</option>
  <option value="1998">
  1998</option>
  <option value="1997">
  1997</option>
  <option value="1996">
  1996</option>
  <option value="1995">
  1995</option>
  <option value="1994">
  1994</option>
  <option value="1993">
  1993</option>
  <option value="1992">
  1992</option>
  <option value="1991">
  1991</option>
  <option value="1990">
  1990</option>
  <option value="1989">
  1989</option>
  <option value="1988">
  1988</option>
  <option value="1987">
  1987</option>
  <option value="1986">
  1986</option>
  <option value="1985">
  1985</option>
  <option value="1984">
  1984</option>
  <option value="1983">
  1983</option>
  <option value="1982">
  1982</option>
  <option value="1981">
  1981</option>
  <option value="1980">
  1980</option>
  <option value="1979">
  1979</option>
  <option value="1978">
  1978</option>
  <option value="1977">
  1977</option>
  <option value="1976">
  1976</option>
  <option value="1975">
  1975</option>
  <option value="1974">
  1974</option>
  <option value="1973">
  1973</option>
  </select>
  </label>
  </section>

  <div id="cgpa_row" style="display: none;">

  <section class="col col-2">

  <label class="label">Obtained CGPA</label>
  <label class="input">
  <input type="number" name="CGPA" pattern="[0-9]" step=".01" max="5" id="idcgpa">

  </label>

  </section>

  <section class="col col-2">

  <label class="label">Total CGPA</label>
  <label class="input">
  <div class="select2-container form-control" id="s2id_autogen125" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-126">4</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen126" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-126" id="s2id_autogen126"><div class="select2-drop select2-display-none select2-with-searchbox">   <div class="select2-search">       <label for="s2id_autogen126_search" class="select2-offscreen"></label>       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input" role="combobox" aria-expanded="true" aria-autocomplete="list" aria-owns="select2-results-126" id="s2id_autogen126_search" placeholder="">   </div>   <ul class="select2-results" role="listbox" id="select2-results-126">   </ul></div></div><select name="T_CGPA" class="form-control select2-offscreen" title="" tabindex="-1">
  <option value="4">4</option>
  <option value="5">5</option>
  </select>
  </label>
  </section>
  </div>

  </div>
  <div class="row" id="degree_marks_row">

  <section class="col col-2">
  <label class="label"><b>Obtained Marks</b></label>
  <label class="input">
  <input type="number" name="OBTAINED_MARKS" id="OBTAINED_MARKS" min="1" pattern="[0-9]" step=".01" required="">
  </label>
  </section>
  <section class="col col-2">
  <label class="label">Total Marks</label>
  <label class="input">
  <input type="number" name="TOTAL_MARKS" id="TOTAL_MARKS" min="4" required="">
  </label>
  </section>


  <section class="col col-2">
  <label class="label">Percentage</label>
  <label class="input">
  <input type="number" min="1" pattern="[0-9]" step=".01" name="PERC" id="PERC" maxlength="5" class="form-control" required="">
  </label>
  </section>

  <section class="col col-6" id="subject_marks_row" style="border-left: 1px solid grey; display: none;"> 

  <section class="col col-4">
  <label class="label" style="font-size: 11px;"><b>Major Subject</b></label>
  <label class="input">
<div class="select2-container form-control" id="s2id_majorsubj" title=""><a href="javascript:void(0)" class="select2-choice" tabindex="-1">   <span class="select2-chosen" id="select2-chosen-127">Select Subject</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow" role="presentation"><b role="presentation"></b></span></a><label for="s2id_autogen127" class="select2-offscreen"></label><input class="select2-focusser select2-offscreen" type="text" aria-haspopup="true" role="button" aria-labelledby="select2-chosen-127" id="s2id_autogen127"><div class="select2-drop select2-display-none select2-with-searchbox">   <div class="select2-search">       <label for="s2id_autogen127_search" class="select2-offscreen"></label>       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input" role="combobox" aria-expanded="true" aria-autocomplete="list" aria-owns="select2-results-127" id="s2id_autogen127_search" placeholder="">   </div>   <ul class="select2-results" role="listbox" id="select2-results-127">   </ul></div></div><select id="majorsubj" name="majorsubj" class="form-control select2-offscreen" title="" tabindex="-1">
  <option value="">Select Subject</option>
  <option value="1">Arabic </option>
  <option value="2">Biotechnology </option>
  <option value="3">Botany </option>
  <option value="4">Chemistry </option>
  <option value="6">Commerce </option>
  <option value="7">Computer Science </option>
  <option value="8">Economics </option>
  <option value="9">Education </option>
  <option value="10">English Literature </option>
  <option value="11">Environmental Science</option>
  <option value="12">Geography</option>
  <option value="13">History</option>
  <option value="14">International Relations</option>
  <option value="15">Islamic Studies</option>
  <option value="16">Information Technology</option>
  <option value="17">Library &amp; Information Science</option>
  <option value="18">Mass Communication</option>
  <option value="19">Mathematicse</option>
  <option value="20">Pakistan Studies</option>
  <option value="21">Physical Education and Sports Science*</option>
  <option value="22">Physics</option>
  <option value="23">Political Science</option>
  <option value="24">Public Administration</option>
  <option value="25">Punjabi</option>
  <option value="26">Sociology</option>
  <option value="27">Statistics</option>
  <option value="28">Urdu</option>
  <option value="29">Zoology</option>
  <option value="30">Applied Psychology</option>
  <option value="31">Food Science</option>
  <option value="32">Biochemistry</option>
  <option value="33">Physiology</option>
  <option value="34">Pharmacology</option>
  <option value="35">Pharmaceutics</option>
  <option value="36">Pharmaceutics</option>
  <option value="37">Psychology</option>
  <option value="38">Business Administration</option>
  <option value="39">Electrical Engineering</option>
  <option value="40">Human Nutrition and Dietetics</option>
  <option value="41">Microbiology</option>
  <option value="42">Linguistics</option>
  <option value="43">Bioinformatics</option>
  <option value="44">Clinical Psychology</option>
  <option value="45">Analytical Chemistry</option>
  <option value="46">Applied Chemistry</option>
  <option value="47">Applied Linguistics</option>
  <option value="48">Inorganic Chemistry</option>
  <option value="49">International Relations</option>
  <option value="50">LAW</option>
  <option value="51">Organic Chemistry</option>
  <option value="52">Physical Chemistry</option>
  <option value="53">Phytomedicine</option>
  <option value="54">Pharmacy Practice</option>
  <option value="55">Software Engineering</option>
  <option value="56">Phytomedicine</option>  
  <option value="57">Food Nutrition</option>
  <option value="58">MBA Executive</option>
  <option value="59">MBA</option> 
  <option value="60">Accounting</option>  
  <option value="61">Marketing</option>  
  <option value="62">Finance</option>
  <option value="63">Business</option>
  <option value="64">Bank &amp; Finance</option>
  <option value="65">Human Resource Managment</option>
  <option value="66">Agribusiness</option>

  </select>
  </label>
  </section>


  <section class="col col-4">
  <label class="label" style="font-size: 11px;"><b>Subject Obtained Marks</b></label>
  <label class="input">
  <input type="text" name="SUB_OBTAINED_MARKS" id="SUB_OBTAINED_MARKS">
  </label>
  </section>
  <section class="col col-4">
  <label class="label" style="font-size: 11px;">Subject Total Marks</label>
  <label class="input">
  <input type="text" name="SUB_TOTAL_MARKS" id="SUB_TOTAL_MARKS">
  </label>
  </section>

  <section class="col col-2" style="display: none;">
  <label class="label">Percentage</label>
  <label class="input">
  <!-- <input type="text" name="SUB_PERC" id="SUB_PERC" class="form-control" readonly > -->

  <input type="number" min="1" pattern="[0-9]" step=".01" name="SUB_PERC" id="SUB_PERC" maxlength="5" class="form-control">
  </label>
  </section>

  <span style="float: left; font-weight: bold;font-size: 14px;">&nbsp;&nbsp;&nbsp;&nbsp;Relevant to Subject(s) In Which You Want you apply</span>
  </section>


  </div>


  </fieldset>

  <footer>


  <div class="animated fadeInUp" style="display: flex;align-items: center;justify-content: center;">          

  <button type="submit" name="submit" id="submit1" accesskey="s" class="btn btn-success" title="Save Date">
  Save Record
  </button>

  </div>
  </footer>
</form>