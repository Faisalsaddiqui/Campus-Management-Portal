<label class="input">
  <select class="form-row" name="PROGRAM_ID" id="PROGRAM_ID" required="">
                <option value="">Select Program</option>
  
          SELECT DISTINCT PROGRAM_TITLE,DEPARTMENT_ID, PROGRAM_ID 
              FROM PROGRAMS WHERE LEVEL_CODE = '5' AND WEB_VIEW1='Y' AND FACULTY_ID!=49 AND CAMPUS_ID='0' AND MIN_MARKS&lt;='56' ORDER BY PROGRAM_TITLE ASC
          <option style="font-size:10px; " value="6146">Associate Degree in  Public Administration</option>
                  
          
          <option style="font-size:10px; " value="6435">Associate Degree in Accounting and Finance</option>
                  
          
          <option style="font-size:10px; " value="6129">Associate Degree in Applied Psychology</option>
                  
          
          <option style="font-size:10px; " value="6143">Associate Degree in Business Administration</option>
                  
          
          <option style="font-size:10px; " value="6142">Associate Degree in Commerce</option>
                  
          
          <option style="font-size:10px; " value="6135">Associate Degree in Computer Science</option>
                  
          
          <option style="font-size:10px; " value="6122">Associate Degree in Economics</option>
                  
          
          <option style="font-size:10px; " value="6440">Associate Degree in Food Sciences &amp; Technology</option>
                  
          
          <option style="font-size:10px; " value="6127">Associate Degree in Information Technology</option>
                  
          
          <option style="font-size:10px; " value="5134">B.Ed. (H) Elementary</option>
                  
          
          <option style="font-size:10px; " value="5226">B.Sc. Chemical Engineering Technology</option>
                  
          
          <option style="font-size:10px; " value="5224">B.Sc. Civil Engineering Technology</option>
                  
          
          <option style="font-size:10px; " value="5222">B.Sc. Electrical Engineering Technology</option>
                  
          
          <option style="font-size:10px; " value="5223">B.Sc.Mechanical Engineering Technology</option>
                  
          
          <option style="font-size:10px; " value="7451">BBA Business Administration</option>
                  
          
          <option style="font-size:10px; " value="6194">BFA - Fine Arts</option>
                  
          
          <option style="font-size:10px; " value="5281">BS (Hons.) Applied Chemistry</option>
                  
          
          <option style="font-size:10px; " value="5282">BS (Hons.) Bio Chemistry</option>
                  
          
          <option style="font-size:10px; " value="5314">BS (Hons.) Food Science and Technology</option>
                  
          
          <option style="font-size:10px; " value="5313">BS (Hons.) Human Nutrition and Dietetics </option>
                  
          
          <option style="font-size:10px; " value="5452">BS Accounting and Finance</option>
                  
          
          <option style="font-size:10px; " value="5111">BS Applied Psychology</option>
                  
          
          <option style="font-size:10px; " value="5511">BS Arabic</option>
                  
          
          <option style="font-size:10px; " value="51221">BS Architecture</option>
                  
          
          <option style="font-size:10px; " value="5264">BS Bioinformatics</option>
                  
          
          <option style="font-size:10px; " value="5262">BS Biotechnology</option>
                  
          
          <option style="font-size:10px; " value="5291">BS Botany</option>
                  
          
          <option style="font-size:10px; " value="5201">BS Chemistry</option>
                  
          
          <option style="font-size:10px; " value="5431">BS Commerce</option>
                  
          
          <option style="font-size:10px; " value="5211">BS Computer Science</option>
                  
          
          <option style="font-size:10px; " value="51212">BS Data Analytics</option>
                  
          
          <option style="font-size:10px; " value="51211">BS Data Science</option>
                  
          
          <option style="font-size:10px; " value="5121">BS Economics</option>
                  
          
          <option style="font-size:10px; " value="5141">BS English Literature</option>
                  
          
          <option style="font-size:10px; " value="5102">BS English Literature and Linguistics  </option>
                  
          
          <option style="font-size:10px; " value="5301">BS Environmental Science</option>
                  
          
          <option style="font-size:10px; " value="5321">BS Geography</option>
                  
          
          <option style="font-size:10px; " value="5161">BS History</option>
                  
          
          <option style="font-size:10px; " value="5311">BS Home Economics</option>
                  
          
          <option style="font-size:10px; " value="5212">BS Information Technology</option>
                  
          
          <option style="font-size:10px; " value="5173">BS International Relations</option>
                  
          
          <option style="font-size:10px; " value="5521">BS Islamic Studies</option>
                  
          
          <option style="font-size:10px; " value="5151">BS Mass Communication</option>
                  
          
          <option style="font-size:10px; " value="5331">BS Mathematics</option>
                  
          
          <option style="font-size:10px; " value="5341">BS Microbiology</option>
                  
          
          <option style="font-size:10px; " value="5162">BS Pakistan Studies</option>
                  
          
          <option style="font-size:10px; " value="3553">BS Persian</option>
                  
          
          <option style="font-size:10px; " value="3372">BS Physical Education And Sports Sciences</option>
                  
          
          <option style="font-size:10px; " value="5231">BS Physics</option>
                  
          
          <option style="font-size:10px; " value="5361">BS Physiology</option>
                  
          
          <option style="font-size:10px; " value="5171">BS Political Science</option>
                  
          
          <option style="font-size:10px; " value="5172">BS Politics and Parliamentary Studies</option>
                  
          
          <option style="font-size:10px; " value="5451">BS Public Administration</option>
                  
          
          <option style="font-size:10px; " value="5351">BS Punjabi</option>
                  
          
          <option style="font-size:10px; " value="6121">BS Remote Sensing and GIS</option>
                  
          
          <option style="font-size:10px; " value="5181">BS Sociology</option>
                  
          
          <option style="font-size:10px; " value="5213">BS Software Engineering</option>
                  
          
          <option style="font-size:10px; " value="5251">BS Statistics</option>
                  
          
          <option style="font-size:10px; " value="5541">BS Urdu</option>
                  
          
          <option style="font-size:10px; " value="5241">BS Zoology</option>
                  
          
          <option style="font-size:10px; " value="5611">LL.B (Hons) Programme</option>
                  
                  
          </select>
          </label>